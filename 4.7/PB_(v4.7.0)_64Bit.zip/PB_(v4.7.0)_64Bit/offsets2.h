/*游戏进程: PUBG MOBILE(com.tencent.ig)
ABI架构: 64位
版本/UID: 4.7.0/21718
时间: 2026年11月12日 凌晨 04时42分20秒
频道: @SCQVQ
作者: 宋尘 */
#define GNames_Offset 0x901BED0
#define GUObject_Offset 0xF9AE670
#define GetActorArray_Offset 0xB99058C
#define GetActorArray_Offset2 0xADE5ABC
#define ProcessEvent_Offset 0x92925A4
#define GNativeAndroidApp_Offset 0xF6C97A8
#define GetCameraRotation_Offset 0xB0298A0
#define GetCameraLocation_Offset 0xB0298B0
#define LaunchBP_Offset 0x7A3235C //BP追踪
#define ShootBulletInner_Offset 0x731B2FC //Sh追踪
#define UpdateVolleyShootParameters_Offset 0x7373948 //Up追踪
#define LineOfSightTo_Offset 0xABE0AD4 //掩体判断
#define Engine_Offset_CB 0x580A70 //CB自身头
#define Engine_Offset_CD 0xFC4AA70 //CD自身头
#define Actors_Offset 0xA0
#define PostRender_Offset 0xACEC6A4
#define K2_DrawLine_Offset 0xB2F34C8
#define K2_DrawText_Offset 0xB2F3758
#define K2_DrawTextrue_Offset 0xB2F354C
#define Gname_Offset 0xF6CA2D0
#define World_Offset 0xF71A7F4
#define Engine_Offset 0xF71A68C //世界头
#define World_Offset 0xFC61C98

//𝑩𝒚宋尘 @iosZFTY || telegram：@SCQVQ