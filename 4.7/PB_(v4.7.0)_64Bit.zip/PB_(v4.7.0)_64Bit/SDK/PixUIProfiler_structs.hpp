#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:47 
// ------------------------------------------------
namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Enums
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Enum PixUIProfiler.EPxProfilerCapability
enum class EPxProfilerCapability : uint8_t
{
	EPxProfilerCapability__PrintSizeChange = 0,
	EPxProfilerCapability__PrintCountChange = 1,
	EPxProfilerCapability__AsyncInnerData = 2,
	EPxProfilerCapability__Count   = 3,
	EPxProfilerCapability__EPxProfilerCapability_MAX = 4
};



}

