#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:47 
// ------------------------------------------------
namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Enums
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Enum UIParticleSystem2.UIMeshProjectionMethod
enum class EUIMeshProjectionMethod : uint8_t
{
	YOZOrtho                       = 0,
	XOYOrtho                       = 1,
	YOZPerspectiveFullScreen       = 2,
	YOZPerspectiveLocal            = 3,
	UIMeshProjectionMethod_MAX     = 4
};



}

