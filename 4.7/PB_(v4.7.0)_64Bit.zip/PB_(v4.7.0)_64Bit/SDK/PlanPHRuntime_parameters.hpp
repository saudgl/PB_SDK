#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:47 
// ------------------------------------------------
#include "../SDK.hpp"

namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Parameters
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Function PlanPHRuntime.BinFileHelper.Init
struct UBinFileHelper_Init_Params
{
	int                                                z4BufferSize;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                zeroListSize;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.MapBarrierWidget.SetMapStructureData
struct UMapBarrierWidget_SetMapStructureData_Params
{
	TArray<struct FStructureData>                      InMapStructureData;                                       // (ConstParm, Parm, ZeroConstructor)
};

// Function PlanPHRuntime.MapBarrierWidget.SetMapMidPoint
struct UMapBarrierWidget_SetMapMidPoint_Params
{
	struct FVector2D                                   InMapMidPoint;                                            // (Parm, OutParm, IsPlainOldData)
};

// Function PlanPHRuntime.MapBarrierWidget.SetLevelBoundExtent
struct UMapBarrierWidget_SetLevelBoundExtent_Params
{
	int                                                InLevelBoundExtent;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.MapBarrierWidget.SetGridSize
struct UMapBarrierWidget_SetGridSize_Params
{
	float                                              InGridSize;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPH_GameMode.HandleNavigationInfo
struct APlanPH_GameMode_HandleNavigationInfo_Params
{
	class AController*                                 Controller;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPH_GameMode.GetPlayerStart
struct APlanPH_GameMode_GetPlayerStart_Params
{
	int                                                LandId;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	class ASTExtraPlayerStart*                         ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPH_GameMode.DSPlayerKickOut
struct APlanPH_GameMode_DSPlayerKickOut_Params
{
	uint64_t                                           UID;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PlayerType;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ExitReason;                                               // (Parm, ZeroConstructor)
};

// Function PlanPHRuntime.PlanPH_GameState.OnRep_PartyDanceLeadInfo_5
struct APlanPH_GameState_OnRep_PartyDanceLeadInfo_5_Params
{
};

// Function PlanPHRuntime.PlanPH_GameState.OnRep_PartyDanceLeadInfo_4
struct APlanPH_GameState_OnRep_PartyDanceLeadInfo_4_Params
{
};

// Function PlanPHRuntime.PlanPH_GameState.OnRep_PartyDanceLeadInfo_3
struct APlanPH_GameState_OnRep_PartyDanceLeadInfo_3_Params
{
};

// Function PlanPHRuntime.PlanPH_GameState.OnRep_PartyDanceLeadInfo_2
struct APlanPH_GameState_OnRep_PartyDanceLeadInfo_2_Params
{
};

// Function PlanPHRuntime.PlanPH_GameState.LuaOnRep_PartyDanceLeadInfo
struct APlanPH_GameState_LuaOnRep_PartyDanceLeadInfo_Params
{
	int                                                LandId;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPH_GameState.ChangePartyLeadInfo
struct APlanPH_GameState_ChangePartyLeadInfo_Params
{
	int                                                LandId;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bOccupied;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                BeginTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                EndTime;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     PlayerUID;                                                // (Parm, ZeroConstructor)
	bool                                               bIsWedding;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPH_PlayerState.RequestPaintDecal
struct APlanPH_PlayerState_RequestPaintDecal_Params
{
	int                                                DecalId;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform                                  TargetTransform;                                          // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPH_PlayerState.OnRep_LandId
struct APlanPH_PlayerState_OnRep_LandId_Params
{
};

// Function PlanPHRuntime.PlanPH_PlayerState.InitLandId
struct APlanPH_PlayerState_InitLandId_Params
{
};

// Function PlanPHRuntime.PlanPH_PlayerState.CanPaintDecal
struct APlanPH_PlayerState_CanPaintDecal_Params
{
	int                                                DecalId;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHCustomStaticMeshComponent.BPPreSetStaticMesh
struct UPlanPHCustomStaticMeshComponent_BPPreSetStaticMesh_Params
{
	class UStaticMesh*                                 NewMesh;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHCustomStaticMeshComponent.BPPostSetStaticMesh
struct UPlanPHCustomStaticMeshComponent_BPPostSetStaticMesh_Params
{
	class UStaticMesh*                                 NewMesh;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHDoor.Refresh_DoorCollisionChanel
struct APlanPHDoor_Refresh_DoorCollisionChanel_Params
{
	class UStaticMeshComponent*                        StaticMeshComponent;                                      // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool                                               bEnableCollision;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHDoor.DoorAniFinish
struct APlanPHDoor_DoorAniFinish_Params
{
	class UStaticMeshComponent*                        InDoorCheckBox;                                           // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool                                               Bright;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHGameplayStatics.SpinEvaluate
struct UPlanPHGameplayStatics_SpinEvaluate_Params
{
	float                                              S;                                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              T;                                                        // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHGameplayStatics.SetPlayerMovementBlendTime
struct UPlanPHGameplayStatics_SetPlayerMovementBlendTime_Params
{
	class ASTExtraPlayerCharacter*                     PlayerChar;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                nType;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              BlendTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHGameplayStatics.GetActorBound
struct UPlanPHGameplayStatics_GetActorBound_Params
{
	class AActor*                                      Actor;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Size;                                                     // (Parm, OutParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHGameplayStatics.ChangeLightChannel
struct UPlanPHGameplayStatics_ChangeLightChannel_Params
{
	class UPrimitiveComponent*                         InComponent;                                              // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                InChannelBitMask;                                         // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHHomeArea.UpdateEditableArea
struct APlanPHHomeArea_UpdateEditableArea_Params
{
	struct FIntVector                                  InMinGridIndexXYZ;                                        // (Parm, IsPlainOldData)
	struct FIntVector                                  InMaxGridIndexXYZ;                                        // (Parm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHHomeAreaVisualizationComponent.ShowGrids
struct UPlanPHHomeAreaVisualizationComponent_ShowGrids_Params
{
	bool                                               InBShow;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHMapData.RemovePlayerItem
struct UPlanPHMapData_RemovePlayerItem_Params
{
	class ASTExtraPlayerCharacter*                     PlayerCharacterItem;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHMapData.AddPlayerItem
struct UPlanPHMapData_AddPlayerItem_Params
{
	class ASTExtraPlayerCharacter*                     PlayerCharacterItem;                                      // (Parm, ZeroConstructor, IsPlainOldData)
	class UWidget*                                     PlayerInfoBPItem;                                         // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UWidget*                                     PlayerInfoRotWidgetItem;                                  // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVector                                     OffsetLocation;                                           // (ConstParm, Parm, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.SubmitProjection
struct UPlanPHProjectionComponent_SubmitProjection_Params
{
};

// Function PlanPHRuntime.PlanPHProjectionComponent.SetReceiverMeshExcluded
struct UPlanPHProjectionComponent_SetReceiverMeshExcluded_Params
{
	class UStaticMesh*                                 Mesh;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bExcluded;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.SetReceiverActorExcluded
struct UPlanPHProjectionComponent_SetReceiverActorExcluded_Params
{
	class AActor*                                      Actor;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bExcluded;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.SetProjectionIntensity
struct UPlanPHProjectionComponent_SetProjectionIntensity_Params
{
	float                                              Intensity;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.SetProjectionEnabled
struct UPlanPHProjectionComponent_SetProjectionEnabled_Params
{
	bool                                               bEnabled;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.ResumeProjectionWorld
struct UPlanPHProjectionComponent_ResumeProjectionWorld_Params
{
	class UObject*                                     WorldContextObject;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.ReleaseProjection
struct UPlanPHProjectionComponent_ReleaseProjection_Params
{
};

// Function PlanPHRuntime.PlanPHProjectionComponent.CleanupProjectionWorld
struct UPlanPHProjectionComponent_CleanupProjectionWorld_Params
{
	class UObject*                                     WorldContextObject;                                       // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.BeginProjection
struct UPlanPHProjectionComponent_BeginProjection_Params
{
	class UObject*                                     BatchHelper;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.AddReceiverActor
struct UPlanPHProjectionComponent_AddReceiverActor_Params
{
	class AActor*                                      Actor;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHProjectionComponent.AddDecorationActor
struct UPlanPHProjectionComponent_AddDecorationActor_Params
{
	class AActor*                                      Actor;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHSpectatorPawn.OnSpectatorRestart
struct APlanPHSpectatorPawn_OnSpectatorRestart_Params
{
};

// Function PlanPHRuntime.PlanPHSpectatorPawn.MoveRight
struct APlanPHSpectatorPawn_MoveRight_Params
{
	float                                              Val;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHSpectatorPawn.MoveForward
struct APlanPHSpectatorPawn_MoveForward_Params
{
	float                                              Val;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHVisualGridComponent.ShowGrids
struct UPlanPHVisualGridComponent_ShowGrids_Params
{
	bool                                               InBShow;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PlanPHRuntime.PlanPHVisualGridComponent.RefreshGrids
struct UPlanPHVisualGridComponent_RefreshGrids_Params
{
};

}

