#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:45 
// ------------------------------------------------
namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Enums
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Enum HiggsBoson.EGymOpType
enum class EGymOpType : uint8_t
{
	EGymOpType__None               = 0,
	EGymOpType__La                 = 1,
	EGymOpType__Sm                 = 2,
	EGymOpType__El                 = 3,
	EGymOpType__No                 = 4,
	EGymOpType__EGymOpType_MAX     = 5
};


// Enum HiggsBoson.EGaraType
enum class EGaraType : uint8_t
{
	EGaraType__Invalid             = 0,
	EGaraType__Alpha               = 1,
	EGaraType__Whale               = 2,
	EGaraType__EGaraType_MAX       = 3
};


// Enum HiggsBoson.EUpdateParamsType
enum class EUpdateParamsType : uint8_t
{
	EUpdateParamsType__RotateLockShooting = 5,
	EUpdateParamsType__WeaponFastReload = 7,
	EUpdateParamsType__Parachute   = 8,
	EUpdateParamsType__SetGameModeMoveSpeedBase = 10,
	EUpdateParamsType__SetGameModeMoveSpeedModifier = 11,
	EUpdateParamsType__MoveUtils   = 12,
	EUpdateParamsType__MoveUtilsSkipSkillID = 14,
	EUpdateParamsType__ClientShootReviewSystem = 16,
	EUpdateParamsType__ClientGlueHiaSystem = 24,
	EUpdateParamsType__RecoilOnWeaponShoot = 30,
	EUpdateParamsType__RecoilOnKickBack = 31,
	EUpdateParamsType__AvatarSkipSlotTypes = 40,
	EUpdateParamsType__FingerTouchFlow = 41,
	EUpdateParamsType__EUpdateParamsType_MAX = 42
};


// Enum HiggsBoson.ECharacterFitnessType
enum class ECharacterFitnessType : uint8_t
{
	ECharacterFitnessType__None    = 0,
	ECharacterFitnessType__DistanceXY = 1,
	ECharacterFitnessType__DistanceZ = 2,
	ECharacterFitnessType__Distance3D = 3,
	ECharacterFitnessType__ABS     = 4,
	ECharacterFitnessType__ContinuousID = 5,
	ECharacterFitnessType__ContinuousInterval = 6,
	ECharacterFitnessType__SourceSpeedZ = 7,
	ECharacterFitnessType__SourceSpeedZBS = 8,
	ECharacterFitnessType__SourceSpeedXY = 9,
	ECharacterFitnessType__SourceSpeed3D = 10,
	ECharacterFitnessType__TargetSpeedZ = 11,
	ECharacterFitnessType__TargetSpeedZBS = 12,
	ECharacterFitnessType__TargetSpeedXY = 13,
	ECharacterFitnessType__TargetSpeed3D = 14,
	ECharacterFitnessType__BeAttachedToParentTime = 15,
	ECharacterFitnessType__SourcePawnState = 16,
	ECharacterFitnessType__TargetPawnState = 17,
	ECharacterFitnessType__Weapon  = 18,
	ECharacterFitnessType__BBAngle = 19,
	ECharacterFitnessType__RelativeSpeedZ = 20,
	ECharacterFitnessType__RelativeSpeedZBS = 21,
	ECharacterFitnessType__RelativeSpeedXY = 22,
	ECharacterFitnessType__RelativeSpeed3D = 23,
	ECharacterFitnessType__SourceMovementMode = 24,
	ECharacterFitnessType__TargetMovementMode = 25,
	ECharacterFitnessType__SourceMovementBase = 26,
	ECharacterFitnessType__TargetMovementBase = 27,
	ECharacterFitnessType__Half    = 30,
	ECharacterFitnessType__Alpha   = 31,
	ECharacterFitnessType__HealthStatus = 32,
	ECharacterFitnessType__HiPart  = 33,
	ECharacterFitnessType__Accuse  = 35,
	ECharacterFitnessType__BullySpeed = 36,
	ECharacterFitnessType__EGameModeType = 37,
	ECharacterFitnessType__EParachuteState = 38,
	ECharacterFitnessType__RelativeTangentSpeed = 39,
	ECharacterFitnessType__RelativeAngleSpeed = 40,
	ECharacterFitnessType__SinceLastProne = 41,
	ECharacterFitnessType__Full    = 42,
	ECharacterFitnessType__FFAngle = 43,
	ECharacterFitnessType__CHAngle = 44,
	ECharacterFitnessType__CVAngle = 45,
	ECharacterFitnessType__SACount = 46,
	ECharacterFitnessType__MaxDev  = 47,
	ECharacterFitnessType__RandDev = 49,
	ECharacterFitnessType__WeedType = 50,
	ECharacterFitnessType__Dura1   = 51,
	ECharacterFitnessType__Dura2   = 52,
	ECharacterFitnessType__AccEv   = 53,
	ECharacterFitnessType__AccAd   = 54,
	ECharacterFitnessType__ShooterLocationZ = 55,
	ECharacterFitnessType__ShooterAreaID = 56,
	ECharacterFitnessType__ShooterBaseIsMovable = 57,
	ECharacterFitnessType__ECharacterFitnessType_MAX = 58
};


// Enum HiggsBoson.ECoronaClientData
enum class ECoronaClientData : uint8_t
{
	ECoronaClientData__Invalid     = 0,
	ECoronaClientData__BulletFireSpeed = 1,
	ECoronaClientData__CurrentWeaponID = 2,
	ECoronaClientData__GravityZ    = 3,
	ECoronaClientData__MinUndilatedFrameTime = 4,
	ECoronaClientData__ActorTimeDilation = 5,
	ECoronaClientData__ShootInterval = 6,
	ECoronaClientData__ExtraHitPerformScale = 7,
	ECoronaClientData__SwitchWeaponSpeedScale = 8,
	ECoronaClientData__AnimationKick = 9,
	ECoronaClientData__RecoilKickADS = 10,
	ECoronaClientData__AccessoriesVRecoilFactor = 11,
	ECoronaClientData__AccessoriesHRecoilFactor = 12,
	ECoronaClientData__AccessoriesRecoveryFactor = 13,
	ECoronaClientData__JumpMaxCount = 14,
	ECoronaClientData__JumpZVelocity = 15,
	ECoronaClientData__TimeDilation = 16,
	ECoronaClientData__FireTimeID  = 17,
	ECoronaClientData__MaxAcceleration = 19,
	ECoronaClientData__ConfigCollisionDistSqAngle = 21,
	ECoronaClientData__WalkableFloorAngle = 22,
	ECoronaClientData__MaxStepHeight = 23,
	ECoronaClientData__ECoronaClientData_MAX = 24
};



//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Script Structs
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// ScriptStruct HiggsBoson.PendingJudgeStruct
// 0x0050
struct FPendingJudgeStruct
{
	unsigned char                                      UnknownData00[0x50];                                      // 0x0000(0x0050) UNKNOWN PROPERTY: SetProperty HiggsBoson.PendingJudgeStruct.IntervalSet
};

// ScriptStruct HiggsBoson.PatchPoint
// 0x000C
struct FPatchPoint
{
	int                                                Offset;                                                   // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	uint32_t                                           Old;                                                      // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	uint32_t                                           New;                                                      // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct HiggsBoson.MoveInput
// 0x0020
struct FMoveInput
{
	float                                              TimeSeconds;                                              // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              ForwardInputRate;                                         // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              RightInputRate;                                           // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	uint64_t                                           CurrentStates;                                            // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                ZeroMoveInputCount;                                       // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

}

