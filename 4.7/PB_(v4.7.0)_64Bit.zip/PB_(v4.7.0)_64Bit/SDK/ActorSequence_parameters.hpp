#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:48 
// ------------------------------------------------
#include "../SDK.hpp"

namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Parameters
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Function ActorSequence.ActorSequenceComponent.StopPlay
struct UActorSequenceComponent_StopPlay_Params
{
};

// Function ActorSequence.ActorSequenceComponent.StartPlay
struct UActorSequenceComponent_StartPlay_Params
{
	float                                              StartTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ActorSequence.ActorSequenceComponent.OnStopOrFinsh
struct UActorSequenceComponent_OnStopOrFinsh_Params
{
};

// Function ActorSequence.ActorSequenceComponent.GetLength
struct UActorSequenceComponent_GetLength_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

