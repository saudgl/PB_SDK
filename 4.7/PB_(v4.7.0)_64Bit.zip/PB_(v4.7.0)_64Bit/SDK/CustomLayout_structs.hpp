#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:47 
// ------------------------------------------------
namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Enums
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Enum CustomLayout.EAnchorsType
enum class EAnchorsType : uint8_t
{
	EAnchorsType__TopLeft          = 0,
	EAnchorsType__TopCenter        = 1,
	EAnchorsType__TopRight         = 2,
	EAnchorsType__MidLeft          = 3,
	EAnchorsType__MidCenter        = 4,
	EAnchorsType__MidRight         = 5,
	EAnchorsType__BottomLeft       = 6,
	EAnchorsType__BottomCenter     = 7,
	EAnchorsType__BottomRight      = 8,
	EAnchorsType__Other            = 9,
	EAnchorsType__EAnchorsType_MAX = 10
};


// Enum CustomLayout.ESCPDisplayState
enum class ESCPDisplayState : uint8_t
{
	ESCPDisplayState__Foreground   = 1,
	ESCPDisplayState__Background   = 2,
	ESCPDisplayState__Hidden       = 3,
	ESCPDisplayState__ESCPDisplayState_MAX = 4
};



//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Script Structs
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// ScriptStruct CustomLayout.CustomLayoutBlueprintCode
// 0x0008
struct FCustomLayoutBlueprintCode
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct CustomLayout.UIElemLayoutDetail
// 0x0028
struct FUIElemLayoutDetail
{
	int                                                Type;                                                     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Opacity;                                                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Scale;                                                    // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FAnchors                                    AnchorType;                                               // 0x000C(0x0010) (Edit, BlueprintVisible)
	struct FVector2D                                   RelativePos;                                              // 0x001C(0x0008) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               Invalid;                                                  // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0025(0x0003) MISSED OFFSET
};

// ScriptStruct CustomLayout.TouchStatInfo
// 0x0008
struct FTouchStatInfo
{
	int                                                CustomType;                                               // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	uint16_t                                           ScreenSpaceX;                                             // 0x0004(0x0002) (ZeroConstructor, IsPlainOldData)
	uint16_t                                           ScreenSpaceY;                                             // 0x0006(0x0002) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct CustomLayout.DynamicCustomInfo
// 0x0040
struct FDynamicCustomInfo
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty CustomLayout.DynamicCustomInfo.DynamicCustomSoftClass
	class UClass*                                      DynamicCustomAsset;                                       // 0x0028(0x0008) (ZeroConstructor, Deprecated, IsPlainOldData)
	TArray<int>                                        CustomTypes;                                              // 0x0030(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct CustomLayout.DynamicCustomConfig
// 0x0002
struct FDynamicCustomConfig
{
	bool                                               bIsShowInLobby;                                           // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
	bool                                               bIgnoreDPIScale;                                          // 0x0001(0x0001) (Edit, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData)
};

}

