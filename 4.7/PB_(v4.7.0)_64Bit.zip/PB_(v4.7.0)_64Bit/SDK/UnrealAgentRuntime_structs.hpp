#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:48 
// ------------------------------------------------
namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Enums
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Enum UnrealAgentRuntime.EPCGCrossSectionType
enum class EPCGCrossSectionType : uint8_t
{
	EPCGCrossSectionType__Plane    = 0,
	EPCGCrossSectionType__Tube     = 1,
	EPCGCrossSectionType__Box      = 2,
	EPCGCrossSectionType__UChannel = 3,
	EPCGCrossSectionType__Custom   = 4,
	EPCGCrossSectionType__EPCGCrossSectionType_MAX = 5
};



}

