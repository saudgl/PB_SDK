#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:45 
// ------------------------------------------------
namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Enums
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Enum GeneralNode.EGNActionState
enum class EGNActionState : uint8_t
{
	EGNActionState__Uninitialized  = 0,
	EGNActionState__DelayRun       = 1,
	EGNActionState__Running        = 2,
	EGNActionState__Finished       = 3,
	EGNActionState__EGNActionState_MAX = 4
};


// Enum GeneralNode.EGNRunRole
enum class EGNRunRole : uint8_t
{
	EGNRunRole__All                = 7,
	EGNRunRole__Authority          = 4,
	EGNRunRole__Autonomous         = 2,
	EGNRunRole__Simulated          = 1,
	EGNRunRole__AutonomousSimulated = 3,
	EGNRunRole__AutonomousAuthority = 6,
	EGNRunRole__AuthoritySimulated = 5,
	EGNRunRole__EGNRunRole_MAX     = 8
};



//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Script Structs
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// ScriptStruct GeneralNode.GNUniqueInstancedNodeKey
// 0x0010
struct FGNUniqueInstancedNodeKey
{
	class UObject*                                     Object;                                                   // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       Key;                                                      // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct GeneralNode.GNContext
// 0x0010
struct FGNContext
{
	class AActor*                                      Owner;                                                    // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UObject*                                     SourceObject;                                             // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct GeneralNode.GNTargetContext
// 0x0020
struct FGNTargetContext
{
	TArray<class UObject*>                             Targets;                                                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FVector>                             TargetLocations;                                          // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct GeneralNode.GNActionInstance
// 0x0068
struct FGNActionInstance
{
	class UGNAction*                                   Action;                                                   // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FGNContext                                  Context;                                                  // 0x0008(0x0010) (Edit)
	struct FGNTargetContext                            TargetContext;                                            // 0x0018(0x0020) (Edit)
	unsigned char                                      UnknownData00[0x30];                                      // 0x0038(0x0030) MISSED OFFSET
};

// ScriptStruct GeneralNode.GNSharedDelegateWrap
// 0x0018
struct FGNSharedDelegateWrap
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	class UObject*                                     Outer;                                                    // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0010(0x0008) MISSED OFFSET
};

// ScriptStruct GeneralNode.GNMultiSharedDelegateWrap
// 0x0018
struct FGNMultiSharedDelegateWrap
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	class UObject*                                     Outer;                                                    // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0010(0x0008) MISSED OFFSET
};

// ScriptStruct GeneralNode.GNComponentPicker
// 0x0010
struct FGNComponentPicker
{
	class UClass*                                      ComponentClass;                                           // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       ComponentTag;                                             // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct GeneralNode.GNActionRunData
// 0x0048
struct FGNActionRunData
{
	class UGNAction*                                   Action;                                                   // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<class UGNCondition*>                        Conditions;                                               // 0x0008(0x0010) (Edit, ZeroConstructor)
	TArray<class UGNTargetPicker*>                     TargetPickers;                                            // 0x0018(0x0010) (Edit, ZeroConstructor)
	TArray<class UGNTargetFilter*>                     TargetFilters;                                            // 0x0028(0x0010) (Edit, ZeroConstructor)
	struct FGNContext                                  Context;                                                  // 0x0038(0x0010) (Edit)
};

}

