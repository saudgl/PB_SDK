#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:45 
// ------------------------------------------------
namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Classes
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Class MoviePlayer.MoviePlayerSettings
// 0x0028 (0x0050 - 0x0028)
class UMoviePlayerSettings : public UObject
{
public:
	bool                                               bWaitForMoviesToComplete;                                 // 0x0028(0x0001) (Edit, ZeroConstructor, Config, GlobalConfig, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	TArray<struct FString>                             bMoviesAreSkippable;                                      // 0x0030(0x0010) (Edit, ZeroConstructor, Config, GlobalConfig)
	TArray<struct FString>                             StartupMovies;                                            // 0x0040(0x0010) (Edit, ZeroConstructor, Config, GlobalConfig)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MoviePlayer.MoviePlayerSettings");
		return pStaticClass;
	}

};


}

