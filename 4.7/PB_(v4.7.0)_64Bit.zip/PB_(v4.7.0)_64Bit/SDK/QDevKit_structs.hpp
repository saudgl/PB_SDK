#pragma once

// ------------------------------------------------
// SDK生成作者:宋尘
// PUBG MOBILE 游戏位数 (4.7.0 -- 64Bit) 
// Telegram频道: @SCQVQ
// 生成时间:2026年11月12日4:44:48 
// ------------------------------------------------
namespace SDK
{
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------
//Enums
//---------------------𝑩𝒚 宋尘 @SCQVQ---------------------------

// Enum QDevKit.EQFirebaseRemoteConfigStatus
enum class EQFirebaseRemoteConfigStatus : uint8_t
{
	EQFirebaseRemoteConfigStatus__kUnfetched = -1,
	EQFirebaseRemoteConfigStatus__kFetchedSuccessfully = 0,
	EQFirebaseRemoteConfigStatus__kFetchedFailed = 1,
	EQFirebaseRemoteConfigStatus__EQFirebaseRemoteConfigStatus_MAX = 2
};



}

