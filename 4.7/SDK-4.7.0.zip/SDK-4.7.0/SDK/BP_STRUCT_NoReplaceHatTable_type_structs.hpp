#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:13 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_NoReplaceHatTable_type.BP_STRUCT_NoReplaceHatTable_type
// 0x0008
struct FBP_STRUCT_NoReplaceHatTable_type
{
	int                                                HatID_0_5D216F800A402C6843EA6E93078F1134;                 // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ItemID_1_08B9AC000128DBF0655B091409133FA4;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

