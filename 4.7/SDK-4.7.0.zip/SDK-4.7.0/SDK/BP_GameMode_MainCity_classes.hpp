#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:11 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass BP_GameMode_MainCity.BP_GameMode_MainCity_C
// 0x0008 (0x2390 - 0x2388)
class ABP_GameMode_MainCity_C : public AMainCityGameMode
{
public:
	class USceneComponent*                             DefaultSceneRoot;                                         // 0x2388(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_GameMode_MainCity.BP_GameMode_MainCity_C");
		return pStaticClass;
	}


	void UserConstructionScript();
};


}

