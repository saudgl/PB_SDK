#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function SmartAssistant_RobotTips_UIBP.SmartAssistant_RobotTips_UIBP_C.Tick
struct USmartAssistant_RobotTips_UIBP_C_Tick_Params
{
	struct FGeometry*                                  MyGeometry;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData)
	float*                                             InDeltaTime;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function SmartAssistant_RobotTips_UIBP.SmartAssistant_RobotTips_UIBP_C.ExecuteUbergraph_SmartAssistant_RobotTips_UIBP
struct USmartAssistant_RobotTips_UIBP_C_ExecuteUbergraph_SmartAssistant_RobotTips_UIBP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

