#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:06 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass ShineInterface.ShineInterface_C
// 0x0000 (0x0028 - 0x0028)
class UShineInterface_C : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass ShineInterface.ShineInterface_C");
		return pStaticClass;
	}


	void ShowNormal();
	void ShowShine();
};


}

