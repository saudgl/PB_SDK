#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function TeamUp_Member_Menu_UIBP.TeamUp_Member_Menu_UIBP_C.Construct
struct UTeamUp_Member_Menu_UIBP_C_Construct_Params
{
};

// Function TeamUp_Member_Menu_UIBP.TeamUp_Member_Menu_UIBP_C.ExecuteUbergraph_TeamUp_Member_Menu_UIBP
struct UTeamUp_Member_Menu_UIBP_C_ExecuteUbergraph_TeamUp_Member_Menu_UIBP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

