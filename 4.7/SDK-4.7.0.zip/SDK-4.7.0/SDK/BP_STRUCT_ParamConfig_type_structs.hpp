#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_ParamConfig_type.BP_STRUCT_ParamConfig_type
// 0x0014
struct FBP_STRUCT_ParamConfig_type
{
	struct FString                                     ParamName_0_3E5093C0622417BF51FDE5CD07CE52A5;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ParamValue_1_11E112C00B831E5D3BCE331C0CED2AC5;            // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

