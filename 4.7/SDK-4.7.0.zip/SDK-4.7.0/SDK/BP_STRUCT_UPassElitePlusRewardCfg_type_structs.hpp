#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:13 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_UPassElitePlusRewardCfg_type.BP_STRUCT_UPassElitePlusRewardCfg_type
// 0x0010
struct FBP_STRUCT_UPassElitePlusRewardCfg_type
{
	int                                                ID_0_484B46C00244D891464F5D850E5B6684;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                item_id_1_1_1754BE400A43497D325B55AA0FA3AD61;             // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                level_2_56288980547E17F623744E220657290C;                 // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                season_index_3_08A02380705510066BB99C86079B9988;          // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

