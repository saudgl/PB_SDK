#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function OnHitByGrenade.OnHitByGrenade_C.OnHitByCake
struct UOnHitByGrenade_C_OnHitByCake_Params
{
};

}

