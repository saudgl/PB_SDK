#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.DisposePetBubble
struct UPetBubbleComponent_BP_C_DisposePetBubble_Params
{
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.InvokePetBubble
struct UPetBubbleComponent_BP_C_InvokePetBubble_Params
{
	int                                                Bubble_ID;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.SpawnEmoteBubble
struct UPetBubbleComponent_BP_C_SpawnEmoteBubble_Params
{
	int                                                BubbleID;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.OnLoadBubbleTextureCallBack
struct UPetBubbleComponent_BP_C_OnLoadBubbleTextureCallBack_Params
{
	class UObject*                                     Asset;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	int                                                ID;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.OnLoadEffect
struct UPetBubbleComponent_BP_C_OnLoadEffect_Params
{
	class UObject*                                     LoadedObject;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       TexParamName;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.CustomEvent_1
struct UPetBubbleComponent_BP_C_CustomEvent_1_Params
{
	class UObject*                                     LoadedObject;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	int                                                RequestID;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.CustomEvent_2
struct UPetBubbleComponent_BP_C_CustomEvent_2_Params
{
	class UObject*                                     LoadedObject;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	int                                                RequestID;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.MIDOK
struct UPetBubbleComponent_BP_C_MIDOK_Params
{
	class UMaterialInstanceDynamic*                    MaterialInstanceDynamic;                                  // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.ReqSpawnPetBubble
struct UPetBubbleComponent_BP_C_ReqSpawnPetBubble_Params
{
	int                                                BubbleID;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.OnNotifySpawnPetBubble
struct UPetBubbleComponent_BP_C_OnNotifySpawnPetBubble_Params
{
	int                                                BubbleID;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetBubbleComponent_BP.PetBubbleComponent_BP_C.ExecuteUbergraph_PetBubbleComponent_BP
struct UPetBubbleComponent_BP_C_ExecuteUbergraph_PetBubbleComponent_BP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

