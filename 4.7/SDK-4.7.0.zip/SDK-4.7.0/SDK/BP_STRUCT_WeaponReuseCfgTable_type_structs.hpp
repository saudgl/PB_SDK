#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_WeaponReuseCfgTable_type.BP_STRUCT_WeaponReuseCfgTable_type
// 0x0028
struct FBP_STRUCT_WeaponReuseCfgTable_type
{
	int                                                ReuseAttachMeshID_0_5434FBC01C8BEB516724520609513054;     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseAvatarID_1_4546FB007C83124E1571E69B0A8192B4;         // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseDefaultAttachID_2_7C7649C07EECDDC5161C8EEB079CE084;  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseFovID_3_4A896E0025C515CC35B3061B01430A64;            // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseSupportAttachID_4_52FB37C0468A0A5532B875EE0C4070F4;  // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseSupportBulletID_5_2F445C800F9CE3205C956C620DD524E4;  // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeaponBPID_6_133CA14062C42FFD677CE3FD0F9C4324;            // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeaponID_7_4308BCC073680B1B09069F6E07FF9CE4;              // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SensibilitySettingID_8_3ADF9D80659D80D4403A7C5600868484;  // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseDefaultAttachAvatar_9_0FC3BE4007A769455278A94600DB1662;// 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

