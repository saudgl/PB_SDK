#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:11 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_ReddotStyle_type.BP_STRUCT_ReddotStyle_type
// 0x0028
struct FBP_STRUCT_ReddotStyle_type
{
	int                                                ID_0_74F6A58049A834103E3B1D30013AE7E4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Name_1_26D6A28054D141E055A57F1B0AE87705;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Path_2_62750580417D3A10561B39950AE65998;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

