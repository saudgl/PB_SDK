#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function PetSpecifiedAnim.PetSpecifiedAnim_C.ReceiveExecuteAI
struct UPetSpecifiedAnim_C_ReceiveExecuteAI_Params
{
	class AAIController**                              OwnerController;                                          // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	class APawn**                                      ControlledPawn;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PetSpecifiedAnim.PetSpecifiedAnim_C.ExecuteUbergraph_PetSpecifiedAnim
struct UPetSpecifiedAnim_C_ExecuteUbergraph_PetSpecifiedAnim_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

