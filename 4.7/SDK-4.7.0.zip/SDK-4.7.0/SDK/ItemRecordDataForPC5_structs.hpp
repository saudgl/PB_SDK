#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:06 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct ItemRecordDataForPC5.ItemRecordDataForPC5
// 0x0030
struct FItemRecordDataForPC5
{
	int                                                ItemID_3_2C55A5F2477A39E2006109BD19E76D0C;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ItemType_5_B88A873B4FDA20CFAF0E798B7EC9084D;              // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BPID_7_204F423F43E79BBD48973B8D51C6F4D7;                  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FString                                     ItemSmallIcon_10_611147EB460F1885DD467290EF57AAC3;        // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ItemSmallIcon2_12_D841285E4F88F8A3220502B369A1CAE3;       // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

