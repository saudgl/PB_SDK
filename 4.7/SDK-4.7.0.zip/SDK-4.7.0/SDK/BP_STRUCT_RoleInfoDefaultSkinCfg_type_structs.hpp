#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:14 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_RoleInfoDefaultSkinCfg_type.BP_STRUCT_RoleInfoDefaultSkinCfg_type
// 0x0008
struct FBP_STRUCT_RoleInfoDefaultSkinCfg_type
{
	int                                                DefaultID_0_2492BC0016330F327996E8BF0B02B4A4;             // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ItemSubType_1_72D0DE4008A89FD943D1E3060021EDC5;           // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

