#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:14 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_TxMissionExtra_type.BP_STRUCT_TxMissionExtra_type
// 0x0014
struct FBP_STRUCT_TxMissionExtra_type
{
	struct FString                                     key_0_1CBF844014E51DD93070B91D0B8C8B69;                   // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                value_1_101419401426BFC562F3B33D0C66E835;                 // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

