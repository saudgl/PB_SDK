#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:05 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_VehicleRefitParticleTable_type.BP_STRUCT_VehicleRefitParticleTable_type
// 0x0018
struct FBP_STRUCT_VehicleRefitParticleTable_type
{
	struct FString                                     PartileBPPath_0_5E40F7001EF760FC74A533720BB8A4F8;         // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_7D8FDE406414C5ED44FDA70204464694;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                StyleID_2_4BC8E2804CB29D6C7BC616430EFC4DA4;               // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

