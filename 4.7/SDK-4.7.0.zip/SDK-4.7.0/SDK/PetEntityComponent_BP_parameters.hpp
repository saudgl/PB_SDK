#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function PetEntityComponent_BP.PetEntityComponent_BP_C.GetAttachInfoFromTable
struct UPetEntityComponent_BP_C_GetAttachInfoFromTable_Params
{
	struct FFixPetAttachInfo*                          Info;                                                     // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData)
	struct FPetAttachInfo                              ReturnValue;                                              // (Parm, OutParm, ReturnParm)
};

}

