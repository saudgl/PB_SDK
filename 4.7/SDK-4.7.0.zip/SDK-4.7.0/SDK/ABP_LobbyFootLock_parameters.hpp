#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function ABP_LobbyFootLock.ABP_LobbyFootLock_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_LobbyFootLock_AnimGraphNode_SequenceEvaluator_05C0A1B441F4ABB9F509689FFE2ABC8F
struct UABP_LobbyFootLock_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_LobbyFootLock_AnimGraphNode_SequenceEvaluator_05C0A1B441F4ABB9F509689FFE2ABC8F_Params
{
};

// Function ABP_LobbyFootLock.ABP_LobbyFootLock_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_LobbyFootLock_AnimGraphNode_TwoBoneIK_BDA234194CFED3542F2C92B2407309D5
struct UABP_LobbyFootLock_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_LobbyFootLock_AnimGraphNode_TwoBoneIK_BDA234194CFED3542F2C92B2407309D5_Params
{
};

// Function ABP_LobbyFootLock.ABP_LobbyFootLock_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_LobbyFootLock_AnimGraphNode_TwoBoneIK_83B366F247150B2E08BAC8852ADD2310
struct UABP_LobbyFootLock_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_LobbyFootLock_AnimGraphNode_TwoBoneIK_83B366F247150B2E08BAC8852ADD2310_Params
{
};

// Function ABP_LobbyFootLock.ABP_LobbyFootLock_C.ExecuteUbergraph_ABP_LobbyFootLock
struct UABP_LobbyFootLock_C_ExecuteUbergraph_ABP_LobbyFootLock_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

