#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:08 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass BP_VehicleExplosionDamageType.BP_VehicleExplosionDamageType_C
// 0x0000 (0x0158 - 0x0158)
class UBP_VehicleExplosionDamageType_C : public USTExtraDamageType
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_VehicleExplosionDamageType.BP_VehicleExplosionDamageType_C");
		return pStaticClass;
	}

};


}

