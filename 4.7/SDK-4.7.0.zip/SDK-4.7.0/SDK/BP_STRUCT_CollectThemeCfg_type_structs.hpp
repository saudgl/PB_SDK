#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:14 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_CollectThemeCfg_type.BP_STRUCT_CollectThemeCfg_type
// 0x0060
struct FBP_STRUCT_CollectThemeCfg_type
{
	struct FString                                     BigImage_0_62AD750044C481BE18225026013983B5;              // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Image_1_7B27B0807478610815BBC2B20B42DFA5;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemNum_2_6431E78064D0EAB2765668A20E447EED;               // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Season_3_32A712005FCA069634A0DFA405750FEE;                // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Sort_4_2AD9E1C06FE8B0371B463EDE07B58814;                  // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ThemeID_5_3051D7C049CE137F58F906EF04044284;               // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ThemeName_6_4CD794C0722001093DC1806904431435;             // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Version_8_47ADD1403213218343FCA4AA0221E50E;               // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Time_9_1C5A9B800D3567301B46C19207B542B5;                  // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

