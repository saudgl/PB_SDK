#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:05 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_TransSupportConfig_VNG_type.BP_STRUCT_TransSupportConfig_VNG_type
// 0x0040
struct FBP_STRUCT_TransSupportConfig_VNG_type
{
	struct FString                                     languageCode_0_304AFE8018A810121E76A0640E962C35;          // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                languageID_1_5EE4C3007F0B28564BBEEDDA099E9654;            // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     abbreviation_2_165B2C4025E15717066345A104E9F1BE;          // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               isSupported_3_764957401C185393258AE03A06008C04;           // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	struct FString                                     displayName_4_47ECCC80441140EA6B09913A0001D215;           // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

