#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:13 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_RPBranchTaskGroup_type.BP_STRUCT_RPBranchTaskGroup_type
// 0x0018
struct FBP_STRUCT_RPBranchTaskGroup_type
{
	int                                                AwardScores_0_41DA0100284B6BB47D68FCFF02A18393;           // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Index_1_44D787802C8C82E41524A6D60B3F7918;                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ShowSortOrder_2_0BC49AC06076A4D915EB45B201739982;         // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TaskGroupID_3_012434C01B4D044908EEECD905BD7EF4;           // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TaskID_4_57163180708615821D76ADC302BBA264;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TaskType_5_24B696C05DE2BDDB30C1AA260BBD12D5;              // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

