#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:07 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function Common_System_Close_UIBP.Common_System_Close_UIBP_C.PreConstruct
struct UCommon_System_Close_UIBP_C_PreConstruct_Params
{
	bool*                                              IsDesignTime;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Common_System_Close_UIBP.Common_System_Close_UIBP_C.ExecuteUbergraph_Common_System_Close_UIBP
struct UCommon_System_Close_UIBP_C_ExecuteUbergraph_Common_System_Close_UIBP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

