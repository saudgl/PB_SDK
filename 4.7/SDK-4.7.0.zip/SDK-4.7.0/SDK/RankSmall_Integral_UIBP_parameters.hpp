#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:11 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function RankSmall_Integral_UIBP.RankSmall_Integral_UIBP_C.SetRankText
struct URankSmall_Integral_UIBP_C_SetRankText_Params
{
	struct FSlateColor                                 Color;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm)
	struct FSlateColor                                 ShadowColor;                                              // (BlueprintVisible, BlueprintReadOnly, Parm)
	struct FSlateFontInfo                              FontInfo;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function RankSmall_Integral_UIBP.RankSmall_Integral_UIBP_C.SetRankIntegral
struct URankSmall_Integral_UIBP_C_SetRankIntegral_Params
{
	struct FBP_STRUCT_RankIntegralLevel_type           RankIntegralLevel_Info;                                   // (BlueprintVisible, BlueprintReadOnly, Parm)
	bool                                               isStarOpen;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function RankSmall_Integral_UIBP.RankSmall_Integral_UIBP_C.ExecuteUbergraph_RankSmall_Integral_UIBP
struct URankSmall_Integral_UIBP_C_ExecuteUbergraph_RankSmall_Integral_UIBP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

