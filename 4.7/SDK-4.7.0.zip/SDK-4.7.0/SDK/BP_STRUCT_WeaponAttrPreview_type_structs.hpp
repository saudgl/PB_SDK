#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_WeaponAttrPreview_type.BP_STRUCT_WeaponAttrPreview_type
// 0x0018
struct FBP_STRUCT_WeaponAttrPreview_type
{
	struct FString                                     ConfigType_0_48EA5D4043E310FF71D3890308402AD5;            // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ConfigValue_1_1291D40038C95BE404A839810406E835;           // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeaponID_3_31959D003F6A93D401479C2B0773FF04;              // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

