#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:07 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function Lobby_Main_Money_UIBP.Lobby_Main_Money_UIBP_C.Construct
struct ULobby_Main_Money_UIBP_C_Construct_Params
{
};

// Function Lobby_Main_Money_UIBP.Lobby_Main_Money_UIBP_C.ExecuteUbergraph_Lobby_Main_Money_UIBP
struct ULobby_Main_Money_UIBP_C_ExecuteUbergraph_Lobby_Main_Money_UIBP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

