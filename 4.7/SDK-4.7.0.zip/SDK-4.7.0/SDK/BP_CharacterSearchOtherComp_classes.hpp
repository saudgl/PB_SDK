#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass BP_CharacterSearchOtherComp.BP_CharacterSearchOtherComp_C
// 0x0000 (0x0610 - 0x0610)
class UBP_CharacterSearchOtherComp_C : public USTCharacterSearchOtherComp
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_CharacterSearchOtherComp.BP_CharacterSearchOtherComp_C");
		return pStaticClass;
	}

};


}

