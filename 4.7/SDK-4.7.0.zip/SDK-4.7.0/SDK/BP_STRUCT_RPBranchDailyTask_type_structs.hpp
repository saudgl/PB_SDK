#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:13 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_RPBranchDailyTask_type.BP_STRUCT_RPBranchDailyTask_type
// 0x0010
struct FBP_STRUCT_RPBranchDailyTask_type
{
	int                                                Days_0_184707402013355F04EDF38103037C13;                  // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SeasonID_1_210A808057561CBC07823F58089B6094;              // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TaskGroupID_2_62DA4E401A98091F074C66EF0EB17C14;           // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Index_3_3F2A2100707A9D3E30FDC3AF00337BF8;                 // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

