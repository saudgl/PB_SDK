#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:13 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_ThemeExchangeConfig_type.BP_STRUCT_ThemeExchangeConfig_type
// 0x002C
struct FBP_STRUCT_ThemeExchangeConfig_type
{
	struct FString                                     EndTime_0_4D906A0058EBC3A67B84FD07042635E5;               // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ExchangeActivityID_1_2C895FC01972BEF103AC344E0961A054;    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     StartTime_2_777F27C055C0EE9959C6501D07026EF5;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ThemeViewID_3_3A59874002877FFF3B04EC8B010D4E74;           // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

