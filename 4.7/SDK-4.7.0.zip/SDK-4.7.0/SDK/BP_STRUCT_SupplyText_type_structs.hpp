#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:08 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_SupplyText_type.BP_STRUCT_SupplyText_type
// 0x0008
struct FBP_STRUCT_SupplyText_type
{
	int                                                ChatID_0_55CE55406726E16144B6347C05241D24;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                AlternateTextID_1_1256E6805FE8A11C280F72C50934EDE4;       // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

