#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:13 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass BattleItemHandle_Jacket_2720_int.BattleItemHandle_Jacket_2720_int_C
// 0x0000 (0x0B92 - 0x0B92)
class UBattleItemHandle_Jacket_2720_int_C : public UBattleItemHandle_AvatarBP_C
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BattleItemHandle_Jacket_2720_int.BattleItemHandle_Jacket_2720_int_C");
		return pStaticClass;
	}

};


}

