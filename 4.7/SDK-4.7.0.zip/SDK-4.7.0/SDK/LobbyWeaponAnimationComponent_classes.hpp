#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C
// 0x0000 (0x0178 - 0x0178)
class ULobbyWeaponAnimationComponent_C : public UActorComponent
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass LobbyWeaponAnimationComponent.LobbyWeaponAnimationComponent_C");
		return pStaticClass;
	}

};


}

