#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:05 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass CS_ReloadEffect.CS_ReloadEffect_C
// 0x0000 (0x0160 - 0x0160)
class UCS_ReloadEffect_C : public UCameraShake
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass CS_ReloadEffect.CS_ReloadEffect_C");
		return pStaticClass;
	}

};


}

