#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:11 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_UGCModCollection_type.BP_STRUCT_UGCModCollection_type
// 0x0030
struct FBP_STRUCT_UGCModCollection_type
{
	struct FString                                     Desc_0_292848000B65189C739C1FEB0474CA93;                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_628E4B8056CA7ADE0C794F2B060474B4;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     Name_5_6308488003787CA27381BB4004752235;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Sort_4_19B95240385E221B714B7EB004760094;                  // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                RankTab_6_38EAF1002F42126C5547352B0E254D22;               // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

