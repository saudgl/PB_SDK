#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:04 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonLaunchApp
// 0x0020
struct FIOSLaunchDaemonLaunchApp
{
	struct FString                                     AppID;                                                    // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     Parameters;                                               // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonPong
// 0x0048
struct FIOSLaunchDaemonPong
{
	struct FString                                     DeviceID;                                                 // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     DeviceName;                                               // 0x0010(0x0010) (ZeroConstructor)
	struct FString                                     DeviceStatus;                                             // 0x0020(0x0010) (ZeroConstructor)
	struct FString                                     DeviceType;                                               // 0x0030(0x0010) (ZeroConstructor)
	bool                                               bCanPowerOff;                                             // 0x0040(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bCanPowerOn;                                              // 0x0041(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bCanReboot;                                               // 0x0042(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0043(0x0005) MISSED OFFSET
};

// ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonPing
// 0x0001
struct FIOSLaunchDaemonPing
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

}

