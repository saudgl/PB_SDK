#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:13 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_NewbieLoginConfig_type.BP_STRUCT_NewbieLoginConfig_type
// 0x0030
struct FBP_STRUCT_NewbieLoginConfig_type
{
	int                                                Day_0_0279174008902B254B82F0800E4F4369;                   // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward1_1_0C75954018D239453DDCD19F0123C721;               // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward1Number_2_1A662F80659D8E7A19AF5B230579FFE2;         // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward1Time_3_65FF1900204C8EC04F45391C07278DF5;           // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward2_4_0C76958018D239463DDCD19E0123C722;               // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward2Number_5_596E6FC03AC3FC9127DAFF510879FFE2;         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward2Time_6_6A6F99400A61F1D14EF032E407268DF5;           // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward3_7_0C7795C018D239473DDCD1990123C723;               // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward3Number_8_1876B0000FEA6AA807A1F42E0779FFE2;         // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Reward3Time_9_6EE01980747754E24C726DC607298DF5;           // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ClientId_10_34BA32C031E6B47325E07B590C20ACE4;             // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                GroupId_11_62FA1E4063BBAF9768EC3FB307788BB4;              // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

