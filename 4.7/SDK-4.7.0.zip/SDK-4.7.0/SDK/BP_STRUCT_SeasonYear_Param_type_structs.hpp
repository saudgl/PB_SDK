#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:05 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_SeasonYear_Param_type.BP_STRUCT_SeasonYear_Param_type
// 0x0020
struct FBP_STRUCT_SeasonYear_Param_type
{
	struct FString                                     Name_0_2EABD84017F2D1E12E5072E60D08A545;                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Value_1_3FE217402988684F743450D100625465;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

