#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_PSKillSprint_LevelConfig_type.BP_STRUCT_PSKillSprint_LevelConfig_type
// 0x0028
struct FBP_STRUCT_PSKillSprint_LevelConfig_type
{
	int                                                ID_0_1DEA3FC01212630D093D7D080EF82FB4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     LevelIcon_1_6E845CC06CD115293919B1730343FE7E;             // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Name_2_2907FCC041155AAB00A4FCCF08302AC5;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

