#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass BP_PlayEmoteComponent.BP_PlayEmoteComponent_C
// 0x0000 (0x0690 - 0x0690)
class UBP_PlayEmoteComponent_C : public UPlayEmoteComponent
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_PlayEmoteComponent.BP_PlayEmoteComponent_C");
		return pStaticClass;
	}

};


}

