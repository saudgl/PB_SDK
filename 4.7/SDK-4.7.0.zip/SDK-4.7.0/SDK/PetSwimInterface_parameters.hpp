#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:09 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function PetSwimInterface.PetSwimInterface_C.ISetLeaveSwimMode
struct UPetSwimInterface_C_ISetLeaveSwimMode_Params
{
};

// Function PetSwimInterface.PetSwimInterface_C.ISetEnterSwimMode
struct UPetSwimInterface_C_ISetEnterSwimMode_Params
{
	float                                              WaterSurface;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

