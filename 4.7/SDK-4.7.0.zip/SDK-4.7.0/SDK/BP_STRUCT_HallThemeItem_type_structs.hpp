#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_HallThemeItem_type.BP_STRUCT_HallThemeItem_type
// 0x0358
struct FBP_STRUCT_HallThemeItem_type
{
	int                                                itemId_0_05AB9D40399D42531091E2D207055864;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     skinLevelName_1_559291C07BED8CD91D86A5EC06628D85;         // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     skinId_2_21CE1EC00F0DEDC7628895A907AE1B64;                // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     vehicleScale_3_18B1B84057E5C0996932DCA5056D8235;          // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     vehicleRotation_4_531D72400EAEDF437EA1408A07C9FA8E;       // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     vehiclePosition_5_4614D38008FDCBAA5E3100C90801FA6E;       // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     footScale_24_4BAD2E4043BD55FB478A4D300900FB95;            // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     footPosition_25_1A7F498024C4CB9079DDF298005B3F5E;         // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     wheel3Rotation_26_2FB2AC40356A0C6333D8BB1707EAC13E;       // 0x0078(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     wheel2Rotation_27_65D2AC006A4A710226C2155D07EAD03E;       // 0x0088(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     footRotation_28_2787E8403E2686FF58BC4E170073407E;         // 0x0098(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     boatScale_29_31B9A9C03C7F6B3564CF8B540700FF85;            // 0x00A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     motoBoatRotation_30_04D46B80758344F43D3EF9A70C8A70AE;     // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     motoBoatPosition_31_77CBCCC07F3D3A251A0D88AC0CC2704E;     // 0x00C8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     snowMotoPosition_32_387BF50062B2919E27D1FD3B0531B75E;     // 0x00D8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     motoBoatScale_33_138291803415844629D6B7050C0F3605;        // 0x00E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     snowMotoRotation_34_458493C058F89C6D2ABB9C2F0519B87E;     // 0x00F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     boatRotation_35_71A323C047E1D14566F9E3840032E07E;         // 0x0108(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     snowMotoScale_36_5AC319C01C0294ED38E9CF4C0180AD35;        // 0x0118(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     wheel2Position_37_58CA0D4014EB11633925055507E2D09E;       // 0x0128(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     wheel3Position_38_22AA0D80600AACC45AD80A9507E2C19E;       // 0x0138(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     boatPosition_39_649A85002E8015D67CB18E9E001ADF5E;         // 0x0148(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     wheel3Scale_40_4D3DF24024C2CE271C4B56EF06F48405;          // 0x0158(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     wheel2Scale_41_598992005DA8E7D86273D45906048405;          // 0x0168(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     WingmanPosition_42_414A2FC06C5C4E2B488CA8390DDA92DE;      // 0x0178(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     WingmanRotation_43_4E52CE80720D61C4362DADC40DF292FE;      // 0x0188(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     WingmanScale_44_6E85748036070D9208224AC603E82385;         // 0x0198(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Path_45_5E37C9804E67E12859DF6CDD09956758;                 // 0x01A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     TankPosition_46_2FBD9F006D30F70E2613FE950349665E;         // 0x01B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     TankRotation_47_3CC63DC00692B27D2E8180200301677E;         // 0x01C8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     TankScale_48_1FA3C3C079A7AFFD7F9DACF20C90CEB5;            // 0x01D8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ByciclePosition_49_4B11CA4049F810B536A4B1570101CD2E;      // 0x01E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BycicleRotation_50_581A69004FA9244E526FC4D000C9CDCE;      // 0x01F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BycicleScale_51_2D7CCF0038DB2CCC1E1BA6860639F235;         // 0x0208(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     SwitchPosition_52_5868F8000397F90822451EA60573A88E;       // 0x0218(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     SwitchScale_53_24249CC06661ECA353D38F6D0083A915;          // 0x0228(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FighterPosition_54_5933CDC07F0202471C35927D0503252E;      // 0x0238(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FighterRotation_55_663C6C8004B315E02699992404CB25CE;      // 0x0248(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FighterScale_56_783C12804D1A76CE26FE97F108B9B215;         // 0x0258(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     AmphibiousBoatPosition_57_6F8D414056BE0D855EE96F170679AC1E;// 0x0268(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     AmphibiousBoatRotation_58_7C95E000749D23E446A4BA3B0651ACBE;// 0x0278(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     AmphibiousBoatScale_59_015AC600314A3E5622D15E53004C99B5;  // 0x0288(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     HorsePosition_60_097B9BC072FE423B7BA80F8B0916AD6E;        // 0x0298(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     HorseRotation_61_16843A8075A73B840FFBA0C6093EAD8E;        // 0x02A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     HorseScale_62_6698E0803B737BD20A6EAE3D003D6F45;           // 0x02B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BrownSedanPosition_63_77D518400011A7051AC96D120BC25A8E;   // 0x02C8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BrownSedanRotation_64_04DDB7001748940447821BD90B8A5A6E;   // 0x02D8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BrownSedanScale_65_69951D002D440436759176880F634605;      // 0x02E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ElectricBusPosition_66_4B2390C03FBDE3EF55609BED054D56EE;  // 0x02F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ElectricBusRotation_67_582C2F8029D23F28721FBAD00505560E;  // 0x0308(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ElectricBusScale_68_33C055801765375651DEC0470FA5AEF5;     // 0x0318(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     InflatableBoatPosition_69_2A17D980121BB27C512436C3044A534E;// 0x0328(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     InflatableBoatRotation_70_372078402FFAC8DB1BA7473B040253AE;// 0x0338(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     InflatableBoatScale_71_5D1DBE4074813E6F1E34A6E20FDFBE85;  // 0x0348(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

