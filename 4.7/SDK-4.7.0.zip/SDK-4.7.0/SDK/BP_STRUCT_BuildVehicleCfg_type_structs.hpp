#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:14 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_BuildVehicleCfg_type.BP_STRUCT_BuildVehicleCfg_type
// 0x0078
struct FBP_STRUCT_BuildVehicleCfg_type
{
	int                                                AvatarID_0_074F708022B5653A614C87CE036EB054;              // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     PreBuildingEffectPath_1_3B5EA14030DBB0453A383DA1023A41B8; // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     VehiclePath_2_12C488C044D393B946E39C650B562818;           // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BuildEffectPath_3_2193080041CB4792535CCA1209C2BD28;       // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     RecoverEffectPath_4_022F018040FD84BA1E0A6E9A04179C48;     // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BuildEffectPath1_5_78C01440482CE333532CBEE70C2BD221;      // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                VehicleSkinID_6_29A78E002F4C612801A6D1D406E15984;         // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoRide_7_566DB5404C538B196C542F9C02F7C9D5;             // 0x005C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoStore_8_2D273780426E717E294BDA950F7ED1A5;            // 0x005D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bHideCharacter_9_55170FC06AD0E83525FB9EA209990742;        // 0x005E(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x005F(0x0001) MISSED OFFSET
	int                                                OverwriteMaxBuildDist_10_4CCC71C010D83C2B3A3C084104CE7F84;// 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0064(0x0004) MISSED OFFSET
	struct FString                                     VehicleRideAnimPath_11_602B4B004623477A1591F907024D7A98;  // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

