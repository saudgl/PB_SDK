#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:11 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_UGCExposureConfig_type.BP_STRUCT_UGCExposureConfig_type
// 0x0008
struct FBP_STRUCT_UGCExposureConfig_type
{
	int                                                ExposureValue_0_2E0FDF8051962E30376C7E88025DF565;         // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ItemID_1_2956D0805BDD4CF609F3CD9C026AEE14;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

