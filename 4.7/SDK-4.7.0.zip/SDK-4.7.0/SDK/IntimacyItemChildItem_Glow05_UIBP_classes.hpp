#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// WidgetBlueprintGeneratedClass IntimacyItemChildItem_Glow05_UIBP.IntimacyItemChildItem_Glow05_UIBP_C
// 0x0010 (0x0270 - 0x0260)
class UIntimacyItemChildItem_Glow05_UIBP_C : public UUserWidget
{
public:
	class UWidgetAnimation*                            Time1;                                                    // 0x0260(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	class UWidgetAnimation*                            Anim_in;                                                  // 0x0268(0x0008) (BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("WidgetBlueprintGeneratedClass IntimacyItemChildItem_Glow05_UIBP.IntimacyItemChildItem_Glow05_UIBP_C");
		return pStaticClass;
	}

};


}

