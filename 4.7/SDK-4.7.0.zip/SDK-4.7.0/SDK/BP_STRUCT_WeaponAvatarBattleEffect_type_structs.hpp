#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:09 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_WeaponAvatarBattleEffect_type.BP_STRUCT_WeaponAvatarBattleEffect_type
// 0x0078
struct FBP_STRUCT_WeaponAvatarBattleEffect_type
{
	int                                                ID_0_5DEDE54072F9770F24CC59220C975D44;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Opacity_4_248EF8405566ED7775F694880FAEF559;               // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     BgPath_5_57B6EF804218D14414997B550D10FFF8;                // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                IsFixColor_6_3314BA80204E2CFC58913B8B0798DA02;            // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                B_7_16D8F2805F7B045E78F002D109C975D2;                     // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                R_8_16E8F6805F7B046E78F002C109C975C2;                     // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                G_9_16DDF3C05F7B046378F002DA09C975D7;                     // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     EffectPath_11_17EB988040F0D4DA01E4BC790CF448F8;           // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                EmotionID_12_1C80DC003AB2B942245E5E330FDB96D4;            // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                isForbideWeaponIdleAnim_13_3C37E3000333ADA8045CF16700283ABD;// 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     AnimationName_14_1E1DCA4031775317410DA0CE01E60B45;        // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              WeaponEmoteDuration_f_15_4B2BFDC0050D1CF7600E5A800F283086;// 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeaponEmoteID_16_7E0FFE407BE0454123B764C700578824;        // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     KillCounterColor_17_12C59CC045ED27E13703D2110BB22402;     // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     KillCounterEffectColor_18_327610007126A2C264362738013BF0B2;// 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

