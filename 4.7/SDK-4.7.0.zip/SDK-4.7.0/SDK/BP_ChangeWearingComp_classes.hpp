#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:06 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass BP_ChangeWearingComp.BP_ChangeWearingComp_C
// 0x0000 (0x0278 - 0x0278)
class UBP_ChangeWearingComp_C : public UChangeWearingComponent
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_ChangeWearingComp.BP_ChangeWearingComp_C");
		return pStaticClass;
	}

};


}

