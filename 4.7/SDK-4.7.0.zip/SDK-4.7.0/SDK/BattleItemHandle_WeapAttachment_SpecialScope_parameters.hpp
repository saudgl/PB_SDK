#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function BattleItemHandle_WeapAttachment_SpecialScope.BattleItemHandle_WeapAttachment_SpecialScope_C.GetFov
struct UBattleItemHandle_WeapAttachment_SpecialScope_C_GetFov_Params
{
	float                                              FOV;                                                      // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

}

