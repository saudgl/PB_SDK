#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:14 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_DownloaderPakCfg_type.BP_STRUCT_DownloaderPakCfg_type
// 0x0030
struct FBP_STRUCT_DownloaderPakCfg_type
{
	struct FString                                     key_0_71B76680473250F81C56B6100C0D8CF9;                   // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PakContent_1_5754D2004C9795227C9AEB100A912064;            // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PakName_2_78C55B805A737D7C60B2D7E30B444B75;               // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

