#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:10 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Classes
//---------------------By 德码---------------------------

// BlueprintGeneratedClass CharFollowExComponent.CharFollowExComponent_C
// 0x0000 (0x04B0 - 0x04B0)
class UCharFollowExComponent_C : public USTCharFollowExComponent
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass CharFollowExComponent.CharFollowExComponent_C");
		return pStaticClass;
	}

};


}

