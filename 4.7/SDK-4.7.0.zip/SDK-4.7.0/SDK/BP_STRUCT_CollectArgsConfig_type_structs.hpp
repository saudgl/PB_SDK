#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_CollectArgsConfig_type.BP_STRUCT_CollectArgsConfig_type
// 0x0020
struct FBP_STRUCT_CollectArgsConfig_type
{
	struct FString                                     keyCfg_0_557D66000CE6F4B03423C3540AEB6687;                // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     valueCfg_1_0E4CBB00357318485949A9E80184D1F7;              // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

