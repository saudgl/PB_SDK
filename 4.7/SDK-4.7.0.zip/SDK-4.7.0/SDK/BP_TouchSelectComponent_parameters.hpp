#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:09 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 德码---------------------------
//Parameters
//---------------------By 德码---------------------------

// Function BP_TouchSelectComponent.BP_TouchSelectComponent_C.RefreshViewportSize
struct UBP_TouchSelectComponent_C_RefreshViewportSize_Params
{
	struct FVector2D                                   OldSize;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData)
	struct FVector2D                                   NewSize;                                                  // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData)
};

// Function BP_TouchSelectComponent.BP_TouchSelectComponent_C.ModifyTouchLoc
struct UBP_TouchSelectComponent_C_ModifyTouchLoc_Params
{
	struct FGeometry                                   MyGeometry;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector2D                                   TouchLoc;                                                 // (BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector2D                                   ReturnValue;                                              // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function BP_TouchSelectComponent.BP_TouchSelectComponent_C.ReceiveBeginPlay
struct UBP_TouchSelectComponent_C_ReceiveBeginPlay_Params
{
};

// Function BP_TouchSelectComponent.BP_TouchSelectComponent_C.ExecuteUbergraph_BP_TouchSelectComponent
struct UBP_TouchSelectComponent_C_ExecuteUbergraph_BP_TouchSelectComponent_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

