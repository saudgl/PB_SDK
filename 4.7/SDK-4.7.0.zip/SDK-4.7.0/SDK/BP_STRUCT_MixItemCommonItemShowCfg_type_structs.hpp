#pragma once

// 德码 (4.5.0 -- 64Bit) SDK 工具 By 德码
// 此文件生成时间Thu Nov 12 09:19:12 2026
 
namespace SDK
{
//---------------------By 德码---------------------------
//Script Structs
//---------------------By 德码---------------------------

// UserDefinedStruct BP_STRUCT_MixItemCommonItemShowCfg_type.BP_STRUCT_MixItemCommonItemShowCfg_type
// 0x0014
struct FBP_STRUCT_MixItemCommonItemShowCfg_type
{
	struct FString                                     ChildName_0_274D1840452014476EC205370AB8C1A5;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ZOrder_1_69C994804B18E5A67F256F560911E332;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

